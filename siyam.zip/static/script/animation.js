window.sr = ScrollReveal();

sr.reveal('.img', {
    duration: 2000,
    origin: 'bottom',
    distance: '100px',
    delay: 1000
});
sr.reveal('p', {
    duration: 2000,
    origin: 'left',
    distance: '100px',
    delay: 500
});
sr.reveal('.btn', {
    duration: 2000,
    origin: 'bottom',
    distance: '20px',
    delay: 1000
});
sr.reveal('.box', {
    duration: 2000,
    origin: 'bottom',
    distance: '100px',
    delay: 1000
});
sr.reveal('.fas', {
    duration: 2000,
    origin: 'top',
    distance: '50px',
    delay: 1000
});
sr.reveal('.far', {
    duration: 2000,
    origin: 'top',
    distance: '50px',
    delay: 1000
});